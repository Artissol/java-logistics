package com.logistics.utils;

public class APIConstants {
	public static final String LOGISTIC_PROPERTIES = "prism_prop";

	public static final String ENV_KEY = "ENV_KEY";
	public static final String SCHEDULE_JOB = "schedulejob";
	public static final String CANCEL_REQUEST = "cancelrequest";

}
